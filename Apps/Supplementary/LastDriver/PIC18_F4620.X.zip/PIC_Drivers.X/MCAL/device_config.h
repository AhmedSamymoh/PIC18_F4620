/* 
 * File:   device_config.h
 * Author: AhmedElnozahy
 *
 * Created on August 3, 2023, 4:53 PM
 */

#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H


#endif	/* DEVICE_CONFIG_H */

