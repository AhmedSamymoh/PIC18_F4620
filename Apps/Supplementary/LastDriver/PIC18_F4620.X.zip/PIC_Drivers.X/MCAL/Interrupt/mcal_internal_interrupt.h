/* 
 * File:   mcal_internal_interrupt.h
 * Author: AhmedSamy
 *
 * Created on September 27, 2023, 7:16 AM
 */

#ifndef MCAL_INTERNAL_INTERRUPT_H
#define	MCAL_INTERNAL_INTERRUPT_H

/* ------------- Section : Includes ------------- */
#include "mcal_interrupt_config.h"

/* ------------- Section: Macro Declarations ------------- */

/* ------------- Section: Macro Functions Declarations ------------- */

/* ------------- Section: Data Type Declarations ------------- */

/* ------------- Section: Function Declarations -------------*/




#endif	/* MCAL_INTERNAL_INTERRUPT_H */

