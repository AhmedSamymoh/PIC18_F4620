/* 
 * File:   mcal_internal_interrupt.c
 * Author: AhmedSamy
 *
 * Created on September 27, 2023, 7:16 AM
 */

#include "mcal_internal_interrupt.h"