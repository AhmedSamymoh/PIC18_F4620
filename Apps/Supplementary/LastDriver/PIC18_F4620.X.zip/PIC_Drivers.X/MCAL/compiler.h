/* 
 * File:   compiler.h
 * Author: AhmedElnozahy
 *
 * Created on August 3, 2023, 5:00 PM
 */

#ifndef COMPILER_H
#define	COMPILER_H

#include <xc.h>
#include <pic18f4620.h>


#endif	/* COMPILER_H */

