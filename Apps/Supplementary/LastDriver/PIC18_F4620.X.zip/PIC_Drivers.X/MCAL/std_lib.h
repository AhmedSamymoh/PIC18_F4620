/* 
 * File:   std_libraries.h
 * Author: AhmedElnozahy
 *
 * Created on August 3, 2023, 5:01 PM
 */

#ifndef STD_LIB_H
#define	STD_LIB_H

/* Section : Includes */
#include <stdio.h>
#include <stdlib.h>

/* Section: Macro Declarations */

/* Section: Macro Functions Declarations */

/* Section: Data Type Declarations */

/* Section: Function Declarations */


#endif	/* STD_LIB_H */

