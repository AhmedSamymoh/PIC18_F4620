/* 
 * File:   ecu_lcd_cfg.h
 * Author: AhmedSamy
 *
 * Created on September 13, 2023, 11:09 PM
 */

#ifndef ECU_LCD_CFG_H
#define	ECU_LCD_CFG_H



#endif	/* ECU_LCD_CFG_H */

