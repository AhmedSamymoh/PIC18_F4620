/* 
 * File:   ECU_LEC_Config.h
 * Author: AhmedElnozahy
 *
 * Created on August 12, 2023, 11:47 PM
 */

#ifndef ECU_LEC_C_H
#define	ECU_LEC_C_H

/* Section : Includes */

/* Section: Macro Declarations */

/* Section: Macro Functions Declarations */

/* Section: Data Type Declarations */

/* Section: Function Declarations */


#endif	/* ECU_LEC_C_H */

