/* 
 * File:   ecu_dc_motor_cfg.h
 * Author: AhmedSamy
 *
 * Created on August 29, 2023, 6:54 PM
 */

#ifndef ECU_DC_MOTOR_CFG_H
#define	ECU_DC_MOTOR_CFG_H

/* Section : Includes */


/* Section: Macro Declarations */

/* Section: Macro Functions Declarations */

/* Section: Data Type Declarations */

/* Section: Function Declarations */


#endif	/* ECU_DC_MOTOR_CFG_H */

