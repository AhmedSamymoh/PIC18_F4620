/* 
 * File:   ecu_seven_segment_cfg.h
 * Author: AhmedSamy
 *
 * Created on August 31, 2023, 7:51 PM
 */

#ifndef ECU_SEVEN_SEGMENT_CFG_H
#define	ECU_SEVEN_SEGMENT_CFG_H


 
#endif	/* ECU_SEVEN_SEGMENT_CFG_H */

