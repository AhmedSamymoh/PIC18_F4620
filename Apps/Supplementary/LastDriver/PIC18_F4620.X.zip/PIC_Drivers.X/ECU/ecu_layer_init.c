/* 
 * File:   ecu_layer_init.c
 * Author: AhmedElnozahy
 *
 * Created on August 3, 2023, 4:54 PM
 */

#include "ecu_layer_init.h"



//Std_ReturnType ret = E_NOT_OK;



void ecu_layer_intialize(void){

}
