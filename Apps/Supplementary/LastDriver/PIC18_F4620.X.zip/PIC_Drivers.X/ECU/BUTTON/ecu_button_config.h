/* 
 * File:   ecu_button_config.h
 * Author: AhmedSamy
 *
 * Created on August 19, 2023, 11:28 PM
 */

#ifndef ECU_BUTTON_CONFIG_H
#define	ECU_BUTTON_CONFIG_H

/* Section : Includes */


/* Section: Macro Declarations */

/* Section: Macro Functions Declarations */

/* Section: Data Type Declarations */

/* Section: Function Declarations */

#endif	/* ECU_BUTTON_CONFIG_H */

