/* 
 * File:   application.c
 * Author: AhmedElnozahy
 *
 * Created on August 3, 2023, 4:54 PM
 */
#include "application.h"

Std_ReturnType ret = E_NOT_OK;
Led_t led1={
  .port_name = PORTC_INDEX , 
  .pin = GPIO_PIN0,
  .led_status = LED_OFF
};
Led_t led2={
  .port_name = PORTC_INDEX , 
  .pin = GPIO_PIN1,
  .led_status = LED_OFF
};
Led_t led3={
  .port_name = PORTC_INDEX , 
  .pin = GPIO_PIN2,
  .led_status = LED_OFF
};

void int0_myISR(void){
    ret = led_TOG(&led1);

};

void int1_myISR(void){
    ret = led_TOG(&led2);

};

void int2_myISR(void){
    ret = led_TOG(&led3);

};

interrupt_INTx_t int0_obj = {
    .EXT_InterruptHandler = int0_myISR,
    .edge = INTERRUPT_RISING_EDGE,
    .priority = INTERRUPT_HIGH_PRIORITY,
    .source = EXTERNAL_INT0,
    .mcu_pin.port = PORTB_INDEX , 
    .mcu_pin.pin = GPIO_PIN0 ,
    .mcu_pin.direction  = GPIO_DIR_INPUT
};

interrupt_INTx_t int1_obj = {
    .EXT_InterruptHandler = int1_myISR,
    .edge = INTERRUPT_FALLING_EDGE,
    .priority = INTERRUPT_HIGH_PRIORITY,
    .source = EXTERNAL_INT1,
    .mcu_pin.port = PORTB_INDEX , 
    .mcu_pin.pin = GPIO_PIN1 ,
    .mcu_pin.direction  = GPIO_DIR_INPUT
};

interrupt_INTx_t int2_obj = {
    .EXT_InterruptHandler = int2_myISR,
    .edge = INTERRUPT_RISING_EDGE,
    .priority = INTERRUPT_HIGH_PRIORITY,
    .source = EXTERNAL_INT2,
    .mcu_pin.port = PORTB_INDEX , 
    .mcu_pin.pin = GPIO_PIN2 ,
    .mcu_pin.direction  = GPIO_DIR_INPUT
};


int main(){
    
    application_intialize();
    ret = interrupt_INTx_Init(&int0_obj);
    ret = interrupt_INTx_Init(&int1_obj);
    ret = interrupt_INTx_Init(&int2_obj);
    while(1)
    {

    } 
    return (EXIT_SUCCESS);
}

void application_intialize(void){
    Std_ReturnType ret = E_NOT_OK;
    //ecu_layer_intialize();
    ret = led_init(&led1); 
    ret = led_init(&led2); 
    ret = led_init(&led3); 


}